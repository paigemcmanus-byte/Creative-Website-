import {useEffect, useRef} from 'react';
import {callouts, headline, tagline} from '../content';
import {clamp, range} from '../lib/math';
import {onFrame} from '../lib/scroll';
import {vars} from '../lib/style';
import Callout, {type CalloutHandle} from './Callout';
import {SunGlyph} from './Marks';
import Nav from './Nav';

function Word({text, delay, className = ''}: {text: string; delay: number; className?: string}) {
  return (
    <span className={`word ${className}`} aria-hidden="true" style={vars({'--d': delay})}>
      {[...text].map((ch, i) => <span key={i} style={vars({'--i': i})}>{ch === ' ' ? '\u00a0' : ch}</span>)}
    </span>
  );
}

/** Scroll turns a clean product sketch from a floating diagonal to a resting pose. */
export default function Hero({reduced}: {reduced: boolean}) {
  const root = useRef<HTMLElement>(null);
  const product = useRef<SVGGElement>(null);
  const calloutEls = useRef<(CalloutHandle | null)[]>([]);

  useEffect(() => {
    const section = root.current;
    if (!section) return;
    const place = () => {
      const w = section.clientWidth;
      const h = window.innerHeight;
      const scale = clamp(Math.min(w / 1440, h / 860), 0.72, 1.12);
      callouts.forEach((co, i) => calloutEls.current[i]?.place(co.anchor[0] * w, co.anchor[1] * h, w, scale));
    };
    // The pinned hero occupies most of its height; map scroll progress to the product pose.
    const draw = () => {
      const rect = section.getBoundingClientRect();
      const span = Math.max(1, section.offsetHeight - window.innerHeight);
      const p = clamp(-rect.top / span, 0, 1);
      const eased = reduced ? 1 : range(p, 0, 0.88);
      const tilt = -24 + 24 * eased;
      const rise = 28 - 28 * eased;
      product.current?.setAttribute('transform', `translate(0 ${rise}) rotate(${tilt} 800 470)`);
      const on = !reduced && p > 0.76;
      calloutEls.current.forEach((el) => el?.show(on));
    };
    place();
    draw();
    const off = onFrame(draw);
    const ro = new ResizeObserver(() => { place(); draw(); });
    ro.observe(section);
    window.addEventListener('resize', place);
    return () => { off(); ro.disconnect(); window.removeEventListener('resize', place); };
  }, [reduced]);

  return (
    <section id="top" ref={root} className="relative" style={{height: reduced ? '100svh' : '380svh'}} aria-label="SealSkin concept introduction">
      <div className="sticky top-0 h-svh overflow-hidden bg-night">
        <div className="absolute inset-0 hero-glow" aria-hidden="true" />
        <svg className="absolute inset-0 size-full" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Illustration of a proposed compact SealSkin brush applicator. This is a concept, not a finished product.">
          <defs>
            <linearGradient id="glass" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#fff8f0" stopOpacity=".84"/><stop offset=".35" stopColor="#f6c4cf" stopOpacity=".5"/><stop offset="1" stopColor="#6e243b" stopOpacity=".9"/></linearGradient>
            <linearGradient id="cap" x1="0" y1="0" x2="1" y2="0"><stop stopColor="#f5e5dc"/><stop offset=".5" stopColor="#fffaf2"/><stop offset="1" stopColor="#b88686"/></linearGradient>
            <linearGradient id="label" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#f5e6d9"/><stop offset="1" stopColor="#e6c8bd"/></linearGradient>
            <filter id="shadow" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="24"/></filter>
          </defs>
          <ellipse cx="800" cy="735" rx="178" ry="32" fill="#ed7196" opacity=".3" filter="url(#shadow)" />
          <g ref={product} transform="translate(0 28) rotate(-24 800 470)" className="product-sketch">
            {/* Illustrative, unbranded packaging proposal: bottle and brush cap. */}
            <rect x="724" y="242" width="152" height="94" rx="21" fill="url(#cap)" stroke="#fff7ee" strokeOpacity=".65" strokeWidth="3" />
            <path d="M756 259v59M780 259v59M804 259v59M828 259v59M852 259v59" stroke="#8c5960" strokeOpacity=".18" strokeWidth="2" />
            <path d="M769 336h62v40h-62z" fill="#dcc0b8" />
            <rect x="690" y="368" width="220" height="328" rx="56" fill="url(#glass)" stroke="#fff5ec" strokeOpacity=".7" strokeWidth="4" />
            <path d="M714 405q0-16 16-16h18v266h-18q-16 0-16-16z" fill="#fff" opacity=".18" />
            <rect x="709" y="463" width="182" height="158" rx="7" fill="url(#label)" />
            <path d="M730 492h140" stroke="#7c303f" strokeWidth="2" opacity=".45" />
            <text x="800" y="537" textAnchor="middle" fill="#4e1f2e" fontFamily="Arial,sans-serif" fontWeight="700" fontSize="23" letterSpacing="4">SEALSKIN</text>
            <text x="800" y="565" textAnchor="middle" fill="#754552" fontFamily="monospace" fontSize="9" letterSpacing="1.3">PAINT-ON BARRIER CONCEPT</text>
            <path d="M741 592h118" stroke="#7c303f" strokeWidth="1" opacity=".35" />
            <circle cx="800" cy="595" r="3" fill="#9f495b" opacity=".7" />
          </g>
        </svg>
        <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgb(12_7_16/0.72)_0%,transparent_25%,transparent_68%,rgb(12_7_16/0.68)_100%)]" />
        <Nav />
        <div className="pointer-events-none absolute inset-2.5 md:inset-3.5" aria-hidden="true">
          <span className="corner left-0 top-0 border-l border-t" /><span className="corner right-0 top-0 border-r border-t" />
          <span className="corner bottom-0 left-0 border-b border-l" /><span className="corner bottom-0 right-0 border-b border-r" />
        </div>
        <h1 className="sr-only">{headline.join(' ')}</h1>
        <div className="pointer-events-none absolute inset-x-0 top-[calc(5.5rem+4svh)] flex flex-col items-start gap-1 px-[max(1rem,3.4vw)] font-display text-[11vw] font-medium uppercase leading-[0.78] tracking-[-0.045em] text-bone md:top-[calc(5rem+6svh)] md:flex-row md:justify-between md:gap-0 md:text-mega">
          <Word text={headline[0]} delay={120} />
          <Word text={headline[1]} delay={320} />
        </div>
        <div className="pointer-events-none absolute bottom-[max(1.1rem,4.6svh)] right-[max(1rem,3.4vw)] font-display text-[11vw] font-medium uppercase leading-[0.78] tracking-[-0.045em] text-bone md:text-mega">
          <Word text={headline[2]} delay={480} />
        </div>
        <div className="absolute bottom-[calc(max(1.1rem,4.6svh)+13vw)] left-[max(1rem,3.4vw)] md:bottom-[max(1.1rem,4.6svh)]">
          <SunGlyph className="line-in mb-4 h-4 w-auto text-bone/80 md:mb-6 md:h-5" />
          <p className="font-mono text-tag font-medium uppercase text-bone">
            {tagline.map((line, i) => <span key={line} className="line-in block" style={vars({'--d': 820 + i * 70})}>{line}</span>)}
          </p>
          <p className="mt-4 font-mono text-[0.62rem] uppercase tracking-[.14em] text-bone/65">Proposed concept · not for sale</p>
        </div>
        {callouts.map((co, i) => <Callout key={co.label} label={co.label} side={co.side} ref={(el) => {calloutEls.current[i] = el;}} />)}
      </div>
    </section>
  );
}
