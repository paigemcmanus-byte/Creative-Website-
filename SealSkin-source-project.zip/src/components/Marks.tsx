export function LogoMark({className = ''}: {className?: string}) {
  return (
    <svg viewBox="0 0 32 32" className={className} fill="none" aria-hidden="true">
      <path d="M16 3.5 27 8v7.7c0 6.1-4.1 10.6-11 13-6.9-2.4-11-6.9-11-13V8l11-4.5Z" stroke="currentColor" strokeWidth="1.5" />
      <path d="M16 8.5c-2.5 3.2-4 5.5-4 7.3a4 4 0 0 0 8 0c0-1.8-1.5-4.1-4-7.3Z" fill="var(--color-rose)" />
    </svg>
  );
}

export function SunGlyph({className = ''}: {className?: string}) {
  return (
    <svg viewBox="0 0 46 22" className={className} fill="none" aria-hidden="true">
      <rect x="0.5" y="0.5" width="45" height="21" rx="10.5" stroke="currentColor" />
      <path d="M13 11h20M17 6h12M17 16h12" stroke="currentColor" />
    </svg>
  );
}
