import {useState, type ReactNode} from 'react';

type ThemeKey = 'wear' | 'application' | 'comfort' | 'water';

const themes: Record<ThemeKey, {label: string; count: number; detail: string}> = {
  wear: {label: 'Staying power', count: 19, detail: 'The most frequent theme in this small competitor-review sample. People described both useful wear and cases where liquid bandage did not hold as expected. That makes wear during ordinary movement a priority to prototype and test.'},
  application: {label: 'Application & portability', count: 17, detail: 'Reviews often discussed where and how the product was applied. SealSkin’s compact brush applicator is a design hypothesis: test whether it feels easy to carry, open, apply, and keep clean.'},
  comfort: {label: 'Sting & sensory comfort', count: 12, detail: 'Some reviews mentioned stinging or other sensory concerns. Product ingredients, directions, and use limits would need careful review and appropriate validation before any consumer-facing claims.'},
  water: {label: 'Water & reapplication', count: 7, detail: 'Water exposure and reapplication came up in the sample. A prototype should be evaluated for these situations before describing water resistance or duration.'},
};

const topics: ThemeKey[] = ['wear', 'application', 'comfort', 'water'];

function SectionLabel({number, children}: {number: string; children: ReactNode}) {
  return <p className="mb-5 flex items-center gap-3 font-mono text-[.67rem] uppercase tracking-[.18em] text-rose"><span>{number}</span><span className="h-px w-10 bg-rose/45" />{children}</p>;
}

export default function Story() {
  const [activeTheme, setActiveTheme] = useState<ThemeKey>('wear');
  const active = themes[activeTheme];

  return <div className="story-shell">
    <section id="idea" className="story-section idea-section">
      <div className="story-inner grid gap-12 lg:grid-cols-[.8fr_1.2fr] lg:items-end">
        <div><SectionLabel number="01">The idea</SectionLabel><h2>A little cut shouldn’t<br className="hidden md:block" /> derail the day.</h2></div>
        <div className="max-w-2xl lg:pb-2"><p className="story-lede">SealSkin is a proposed clear, flexible liquid barrier, painted over a small cut or nick and designed to dry into a thin “second skin.”</p><p className="story-copy">The idea is to make minor-cut care feel more portable and less bulky for active teens and young adults. A compact brush-on applicator is one possible direction to explore.</p><p className="concept-note"><strong>Concept only.</strong> SealSkin is not a finished, tested, or available product. This site describes a student venture idea; it does not make medical or performance claims.</p><a className="text-link" href="#fit">See who it’s for <span aria-hidden="true">↓</span></a></div>
      </div>
      <div className="idea-ribbon" aria-hidden="true"><span>PORTABLE BY DESIGN</span><span>BUILT FOR SMALL MOMENTS</span><span>STILL A CONCEPT</span></div>
    </section>

    <section id="fit" className="story-section fit-section">
      <div className="story-inner">
        <SectionLabel number="02">How it might fit</SectionLabel>
        <div className="section-heading-row"><h2>Designed around<br />an active day.</h2><p className="story-copy max-w-sm">The initial audience hypothesis is active people ages 16–30, including college students, young professionals, and athletes.</p></div>
        <div className="fit-grid">
          <article className="fit-card"><span className="fit-index">A / CARRY</span><h3>Small enough to bring along</h3><p>A compact format could fit in a gym bag, backpack, or work kit. Size and applicator design still need testing.</p></article>
          <article className="fit-card"><span className="fit-index">B / APPLY</span><h3>A brush-on idea</h3><p>A paint-on format could be useful in places where a traditional adhesive bandage feels awkward. Actual ease of use is an open question.</p></article>
          <article className="fit-card"><span className="fit-index">C / TRUST</span><h3>Clear about its limits</h3><p>Directions, ingredients, use limits, and clear safety information would matter before anyone considers trying an unfamiliar product.</p></article>
        </div>
        <p className="fit-footnote">These are design hypotheses—not proven benefits or a substitute for appropriate care.</p>
      </div>
    </section>

    <section id="research" className="story-section research-section">
      <div className="story-inner">
        <SectionLabel number="03">What the research suggests</SectionLabel>
        <div className="section-heading-row"><div><h2>Listen first.<br />Test the hard parts.</h2><p className="story-copy mt-5 max-w-lg">Early research points to questions for a prototype—not proof that SealSkin works or that people will buy it.</p></div><div className="research-tag">30 competitor reviews<br />+ 3 simulated participants</div></div>
        <div className="research-panel">
          <div className="theme-list" role="tablist" aria-label="Themes in competitor reviews">
            {topics.map((key) => <button key={key} type="button" role="tab" aria-selected={activeTheme === key} className={`theme-tab ${activeTheme === key ? 'is-active' : ''}`} onClick={() => setActiveTheme(key)}><span>{themes[key].label}</span><span className="theme-number">{themes[key].count}<small> mentions</small></span></button>)}
          </div>
          <div className="theme-detail" role="tabpanel"><p className="eyebrow-small">MOST FREQUENT IN THIS SAMPLE</p><h3>{active.label}</h3><p>{active.detail}</p><div className="mini-bars" aria-label="Frequency of coded review themes">
            {topics.map((key) => <div className="mini-bar-row" key={key}><span>{themes[key].label}</span><div className="mini-track"><span style={{width: `${(themes[key].count / 20) * 100}%`}} /></div><b>{themes[key].count}</b></div>)}
          </div></div>
        </div>
        <div className="evidence-grid">
          <article><span className="evidence-kicker">CATEGORY REVIEWS</span><h3>30 public reviews</h3><p>Fifteen reviews each for two New-Skin liquid-bandage products, manually coded as a convenience sample. Staying power (19 mentions) and application/portability (17) appeared most often.</p><p className="evidence-caveat">These reviews describe other products, not SealSkin. Counts are descriptive of this sample only.</p></article>
          <article><span className="evidence-kicker">AI-SIMULATED DISCUSSION</span><h3>Useful questions, not validation</h3><p>Three fictional OASIS personas raised questions about movement, cleanup, residue, and price. Only five answer segments were usable; later rounds repeated earlier responses.</p><p className="evidence-caveat">Synthetic responses are not human consumer research and are not evidence of demand.</p></article>
        </div>
      </div>
    </section>

    <section id="next" className="story-section next-section">
      <div className="story-inner">
        <SectionLabel number="04">What comes next</SectionLabel>
        <div className="section-heading-row"><h2>Make the questions<br />testable.</h2><p className="story-copy max-w-sm">Before building a campaign around convenience, learn what people need from the product and what the prototype can actually deliver.</p></div>
        <div className="next-grid">
          <div className="next-card"><span>01</span><h3>Prototype the experience</h3><p>Explore application, drying, cleanup, removal, and applicator hygiene.</p></div>
          <div className="next-card"><span>02</span><h3>Test the trade-offs</h3><p>Ask real target customers about wear during movement, water exposure, comfort, directions, and price.</p></div>
          <div className="next-card"><span>03</span><h3>Earn trust before reach</h3><p>Review use limits and substantiate product and safety information before making advertising claims.</p></div>
        </div>
        <div className="closing-note"><p>SealSkin is an early marketing venture concept.</p><a href="#top" className="closing-link">Back to the beginning <span aria-hidden="true">↑</span></a></div>
      </div>
    </section>
    <footer className="site-footer"><span>SEALSKIN · CONCEPT STUDY</span><span>Not for sale · Not medical advice</span><a href="#top">Back to top ↑</a></footer>
  </div>;
}
