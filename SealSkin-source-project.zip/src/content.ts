/** SealSkin is a proposed paint-on liquid-barrier concept, not a product for sale. */

export const brand = 'SEALSKIN';

export const nav = {
  links: [
    {label: 'The Idea', href: '#idea'},
    {label: 'How It Fits', href: '#fit'},
    {label: 'What We Heard', href: '#research'},
    {label: 'Next Steps', href: '#next'},
  ],
  cta: {label: 'Explore the concept', href: '#idea'},
};

export const headline = ['A little', 'cover,', 'on the go.'] as const;

export const tagline = [
  'A proposed paint-on barrier',
  'for small cuts and nicks.',
  'Designed around an active day.',
];

export const callouts = [
  {label: 'Compact applicator concept', anchor: [0.65, 0.43], side: 'right'},
  {label: 'For small cuts & nicks', anchor: [0.37, 0.57], side: 'left'},
] as const;
