import {forwardRef, useEffect, useImperativeHandle, useRef, useState} from 'react';
import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import modelUrl from '../assets/sealskin-confirmed.glb?url';
import previewUrl from '../assets/sealskin-confirmed-preview.png?url';
import manifest from '../assets/sealskin-model-manifest.json';

export type InteractiveModelHandle = {setScrollProgress: (progress: number) => void};
type Props = {reducedMotion: boolean};

const START_YAW = -0.4;

const InteractiveModel = forwardRef<InteractiveModelHandle, Props>(function InteractiveModel({reducedMotion}, ref) {
  const host = useRef<HTMLDivElement>(null);
  const draw = useRef<() => void>(() => {});
  const modelRoot = useRef<THREE.Group | null>(null);
  const sceneState = useRef<{renderer: THREE.WebGLRenderer; camera: THREE.PerspectiveCamera; frameDistance: number; direction: THREE.Vector3} | null>(null);
  const scrollProgress = useRef(0);
  const userYaw = useRef(0);
  const userPitch = useRef(0);
  const zoom = useRef(1);
  const drag = useRef<{x: number; y: number} | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'fallback'>('loading');
  const [message, setMessage] = useState('Preparing the SealSkin 3D concept…');

  useImperativeHandle(ref, () => ({
    setScrollProgress(progress) {
      scrollProgress.current = reducedMotion ? 1 : progress;
      draw.current();
    },
  }), [reducedMotion]);

  useEffect(() => {
    const container = host.current;
    if (!container) return;
    let disposed = false;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({alpha: true, antialias: true, powerPreference: 'low-power'});
    } catch {
      setStatus('fallback');
      setMessage('Interactive 3D is unavailable in this browser. This is the confirmed static preview.');
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.18;
    renderer.setClearColor(0x000000, 0);
    renderer.domElement.className = 'model-canvas';
    renderer.domElement.setAttribute('aria-label', 'Interactive SealSkin 3D concept. Drag to rotate; use the buttons to change view.');
    renderer.domElement.setAttribute('role', 'img');
    container.prepend(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
    const hemi = new THREE.HemisphereLight(0xfff3ed, 0x251520, 2.1);
    scene.add(hemi);
    const key = new THREE.DirectionalLight(0xffe4d7, 3.6);
    key.position.set(-3.5, 5, 5);
    scene.add(key);
    const fill = new THREE.DirectionalLight(0xe59aaf, 1.6);
    fill.position.set(4, 1.5, 3);
    scene.add(fill);
    const rim = new THREE.DirectionalLight(0xb9cfe4, 2.3);
    rim.position.set(1, 3, -4);
    scene.add(rim);

    const pivot = new THREE.Group();
    scene.add(pivot);
    modelRoot.current = pivot;
    let baseDistance = 5;
    let frameWidth = 3.4;
    let frameHeight = 2.55;
    const preferredPosition = new THREE.Vector3().fromArray(manifest.preferredCamera.position);
    const preferredTarget = new THREE.Vector3().fromArray(manifest.preferredCamera.target);
    const direction = preferredPosition.sub(preferredTarget).normalize();
    sceneState.current = {renderer, camera, frameDistance: baseDistance, direction};

    const render = () => {
      if (!sceneState.current) return;
      const {renderer: currentRenderer, camera: currentCamera, frameDistance, direction: cameraDirection} = sceneState.current;
      if (modelRoot.current) {
        modelRoot.current.rotation.y = START_YAW * (1 - scrollProgress.current) + userYaw.current;
        modelRoot.current.rotation.x = userPitch.current;
      }
      currentCamera.position.copy(cameraDirection).multiplyScalar(frameDistance * zoom.current);
      currentCamera.lookAt(0, 0, 0);
      currentRenderer.render(scene, currentCamera);
    };
    draw.current = render;

    const resize = () => {
      const rect = container.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const aspect = rect.width / rect.height;
      camera.aspect = aspect;
      camera.fov = aspect < 0.85 ? 48 : 35;
      camera.updateProjectionMatrix();
      if (sceneState.current) {
        const vertical = 2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
        const distanceForHeight = frameHeight / vertical;
        const distanceForWidth = frameWidth / (vertical * aspect);
        baseDistance = Math.max(4.35, distanceForHeight, distanceForWidth) * 1.12;
        sceneState.current.frameDistance = baseDistance;
      }
      renderer.setSize(rect.width, rect.height, false);
      render();
    };
    const observer = new ResizeObserver(resize);
    observer.observe(container);

    const loader = new GLTFLoader();
    loader.load(modelUrl, (gltf) => {
      if (disposed) return;
      const product = gltf.scene;
      const bounds = new THREE.Box3().setFromObject(product);
      const size = bounds.getSize(new THREE.Vector3());
      const widest = Math.max(size.x, size.y, size.z) || 1;
      const normalization = 3.4 / widest;
      frameWidth = size.x * normalization;
      frameHeight = size.y * normalization;
      product.scale.setScalar(normalization);
      product.updateMatrixWorld(true);
      const center = new THREE.Box3().setFromObject(product).getCenter(new THREE.Vector3());
      product.position.sub(center);
      product.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          object.castShadow = true;
          object.receiveShadow = true;
        }
      });
      pivot.add(product);

      const groundY = -(size.y * normalization) / 2 - 0.025;
      const shadow = new THREE.Mesh(
        new THREE.CircleGeometry(1, 48),
        new THREE.MeshBasicMaterial({color: 0x08060a, transparent: true, opacity: 0.34, depthWrite: false}),
      );
      shadow.rotation.x = -Math.PI / 2;
      shadow.position.y = groundY;
      shadow.scale.set(1.8, 0.72, 1);
      scene.add(shadow);
      setStatus('ready');
      setMessage('Drag to rotate · use the view controls to zoom');
      resize();
    }, undefined, () => {
      if (disposed) return;
      setStatus('fallback');
      setMessage('The 3D model could not load. This is the confirmed static preview.');
    });

    resize();
    return () => {
      disposed = true;
      observer.disconnect();
      renderer.dispose();
      renderer.domElement.remove();
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => material.dispose());
        }
      });
      sceneState.current = null;
      modelRoot.current = null;
      draw.current = () => {};
    };
  }, []);

  const zoomBy = (factor: number) => {
    zoom.current = THREE.MathUtils.clamp(zoom.current * factor, 0.72, 1.65);
    draw.current();
  };
  const reset = () => {
    userYaw.current = 0;
    userPitch.current = 0;
    zoom.current = 1;
    draw.current();
  };
  const setPreset = (yaw: number) => {
    userYaw.current = yaw - START_YAW * (1 - scrollProgress.current);
    userPitch.current = 0;
    draw.current();
  };

  return (
    <div className="model-experience" aria-label="Explore the SealSkin concept model">
      <div ref={host} className={`model-stage ${status === 'ready' ? 'is-ready' : ''}`}>
        <img className={`model-fallback ${status === 'ready' ? 'is-hidden' : ''}`} src={previewUrl} alt="Confirmed static preview of the SealSkin liquid bandage bottle and package" />
        <div className={`model-loading ${status !== 'loading' ? 'is-hidden' : ''}`} role="status">Loading confirmed 3D model…</div>
        {status === 'fallback' && <div className="model-error" role="status">{message}</div>}
      </div>
      <div className="model-controls" aria-label="3D model controls">
        <span className="model-hint">{status === 'ready' ? 'Drag to explore' : status === 'loading' ? 'Preparing model' : 'Static concept preview'}</span>
        <button type="button" onClick={() => setPreset(0)} disabled={status !== 'ready'} aria-label="Show front view">Front</button>
        <button type="button" onClick={() => setPreset(Math.PI / 2)} disabled={status !== 'ready'} aria-label="Show side view">Side</button>
        <button type="button" onClick={() => zoomBy(0.88)} disabled={status !== 'ready'} aria-label="Zoom in">+</button>
        <button type="button" onClick={() => zoomBy(1.14)} disabled={status !== 'ready'} aria-label="Zoom out">−</button>
        <button type="button" onClick={reset} disabled={status !== 'ready'} aria-label="Reset model view">Reset</button>
      </div>
      <p className="model-status" aria-live="polite">{status === 'loading' ? message : status === 'fallback' ? 'Static preview · confirmed Mission 2 model' : 'Mission 2 confirmed model · approximate dimensions'}</p>
      <div
        className="model-drag-target"
        aria-hidden="true"
        onPointerDown={(event) => {
          if (status !== 'ready' || (event.target as HTMLElement).closest('.model-controls')) return;
          drag.current = {x: event.clientX, y: event.clientY};
          event.currentTarget.setPointerCapture(event.pointerId);
        }}
        onPointerMove={(event) => {
          if (!drag.current || !modelRoot.current) return;
          const dx = event.clientX - drag.current.x;
          const dy = event.clientY - drag.current.y;
          drag.current = {x: event.clientX, y: event.clientY};
          userYaw.current += dx * 0.008;
          userPitch.current = THREE.MathUtils.clamp(userPitch.current + dy * 0.004, -0.42, 0.42);
          draw.current();
        }}
        onPointerUp={() => {drag.current = null;}}
        onPointerCancel={() => {drag.current = null;}}
      />
    </div>
  );
});

export default InteractiveModel;
