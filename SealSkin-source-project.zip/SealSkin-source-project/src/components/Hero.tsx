import {lazy, Suspense, useEffect, useRef} from 'react';
import {callouts, headline, tagline} from '../content';
import previewUrl from '../assets/sealskin-confirmed-preview.png?url';
import {clamp, range} from '../lib/math';
import {onFrame} from '../lib/scroll';
import {vars} from '../lib/style';
import Callout, {type CalloutHandle} from './Callout';
import type {InteractiveModelHandle} from './InteractiveModel';
import ModelErrorBoundary from './ModelErrorBoundary';
import {SunGlyph} from './Marks';
import Nav from './Nav';

const InteractiveModel = lazy(() => import('./InteractiveModel'));

function ModelPreview({message}: {message: string}) {
  return (
    <div className="model-experience">
      <div className="model-stage">
        <img className="model-fallback" src={previewUrl} alt="Confirmed static preview of the SealSkin liquid bandage bottle and package" />
        <div className="model-error" role="status">{message}</div>
      </div>
    </div>
  );
}

function Word({text, delay, className = ''}: {text: string; delay: number; className?: string}) {
  return (
    <span className={`word ${className}`} aria-hidden="true" style={vars({'--d': delay})}>
      {[...text].map((ch, i) => <span key={i} style={vars({'--i': i})}>{ch === ' ' ? '\u00a0' : ch}</span>)}
    </span>
  );
}

/** Scroll turns a clean product sketch from a floating diagonal to a resting pose. */
export default function Hero({reduced}: {reduced: boolean}) {
  const root = useRef<HTMLElement>(null);
  const product = useRef<InteractiveModelHandle>(null);
  const calloutEls = useRef<(CalloutHandle | null)[]>([]);

  useEffect(() => {
    const section = root.current;
    if (!section) return;
    let previousModelProgress = -1;
    const place = () => {
      const w = section.clientWidth;
      const h = window.innerHeight;
      const scale = clamp(Math.min(w / 1440, h / 860), 0.72, 1.12);
      callouts.forEach((co, i) => calloutEls.current[i]?.place(co.anchor[0] * w, co.anchor[1] * h, w, scale));
    };
    // Let the confirmed model settle into its front view as visitors move through the hero.
    const draw = () => {
      const rect = section.getBoundingClientRect();
      const span = Math.max(1, section.offsetHeight - window.innerHeight);
      const p = clamp(-rect.top / span, 0, 1);
      const eased = reduced ? 1 : range(p, 0, 0.88);
      if (product.current && Math.abs(eased - previousModelProgress) > 0.001) {
        product.current.setScrollProgress(eased);
        previousModelProgress = eased;
      }
      const on = !reduced && p > 0.76;
      calloutEls.current.forEach((el) => el?.show(on));
    };
    place();
    draw();
    const off = onFrame(draw);
    const ro = new ResizeObserver(() => { place(); draw(); });
    ro.observe(section);
    window.addEventListener('resize', place);
    return () => { off(); ro.disconnect(); window.removeEventListener('resize', place); };
  }, [reduced]);

  return (
    <section id="top" ref={root} className="relative" style={{height: reduced ? '100svh' : '380svh'}} aria-label="SealSkin concept introduction">
      <div className="sticky top-0 h-svh overflow-hidden bg-night">
        <div className="absolute inset-0 hero-glow" aria-hidden="true" />
        <ModelErrorBoundary fallback={<ModelPreview message="Interactive 3D is unavailable here. This is the confirmed static Mission 2 preview." />}>
          <Suspense fallback={<ModelPreview message="Loading the confirmed 3D concept…" />}>
            <InteractiveModel ref={product} reducedMotion={reduced} />
          </Suspense>
        </ModelErrorBoundary>
        <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,rgb(12_7_16/0.72)_0%,transparent_25%,transparent_68%,rgb(12_7_16/0.68)_100%)]" />
        <Nav />
        <div className="pointer-events-none absolute inset-2.5 md:inset-3.5" aria-hidden="true">
          <span className="corner left-0 top-0 border-l border-t" /><span className="corner right-0 top-0 border-r border-t" />
          <span className="corner bottom-0 left-0 border-b border-l" /><span className="corner bottom-0 right-0 border-b border-r" />
        </div>
        <h1 className="sr-only">{headline.join(' ')}</h1>
        <div className="pointer-events-none absolute inset-x-0 top-[calc(5.5rem+4svh)] flex flex-col items-start gap-1 px-[max(1rem,3.4vw)] font-display text-[11vw] font-medium uppercase leading-[0.78] tracking-[-0.045em] text-bone md:top-[calc(5rem+6svh)] md:flex-row md:justify-between md:gap-0 md:text-mega">
          <Word text={headline[0]} delay={120} />
          <Word text={headline[1]} delay={320} />
        </div>
        <div className="pointer-events-none absolute bottom-[max(1.1rem,4.6svh)] right-[max(1rem,3.4vw)] font-display text-[11vw] font-medium uppercase leading-[0.78] tracking-[-0.045em] text-bone md:text-mega">
          <Word text={headline[2]} delay={480} />
        </div>
        <div className="absolute bottom-[calc(max(1.1rem,4.6svh)+13vw)] left-[max(1rem,3.4vw)] md:bottom-[max(1.1rem,4.6svh)]">
          <SunGlyph className="line-in mb-4 h-4 w-auto text-bone/80 md:mb-6 md:h-5" />
          <p className="font-mono text-tag font-medium uppercase text-bone">
            {tagline.map((line, i) => <span key={line} className="line-in block" style={vars({'--d': 820 + i * 70})}>{line}</span>)}
          </p>
          <p className="mt-4 font-mono text-[0.62rem] uppercase tracking-[.14em] text-bone/65">Proposed concept · not for sale</p>
        </div>
        {callouts.map((co, i) => <Callout key={co.label} label={co.label} side={co.side} ref={(el) => {calloutEls.current[i] = el;}} />)}
      </div>
    </section>
  );
}
