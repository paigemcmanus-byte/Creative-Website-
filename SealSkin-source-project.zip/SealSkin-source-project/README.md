# SealSkin concept site source

Editable React/Vite source for the SealSkin student venture website. The hero now loads the confirmed Mission 2 GLB, while the original brand layout, scroll-led introduction, research sections, and navigation remain in place.

SealSkin is a proposed concept, not a finished, tested, or available product. This site is not for sale and does not make medical or performance claims. The 10 mL format and dimensions are approximate.

## Development

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Build production files with `pnpm build`; output is written to `dist/`. The Vite base path matches GitHub Pages at `/Creative-Website-/`.

The GLB is in `src/assets/sealskin-confirmed.glb`; its Mission 2 static preview is `src/assets/sealskin-confirmed-preview.png`. When WebGL or model loading is unavailable, the page clearly presents the static preview.
